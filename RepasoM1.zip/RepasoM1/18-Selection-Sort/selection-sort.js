function selectionSort(arr) {
  // construye un algoritmo de busqueda bubble sort
}
