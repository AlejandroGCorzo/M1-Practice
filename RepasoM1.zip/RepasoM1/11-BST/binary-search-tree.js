class Node {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

class BinarySearchTree {
  constructor() {
    this.root = null;
  }

  insert(value) {
    // escribe un metodo que inserte un nodo al final
  }

  find(value) {
    // escribe un metodo que busque un nodo especifico
  }

  size() {
    // escribe un metodo que determine el largo del arbol
  }

  breadthFirstForEach() {
    // escribe el metodo breadthFirstForEach
  }

  depthFirstForEach(arg) {
    // escribe el metodo depthFirstForEach
  }
}
