function quickSort(arr) {
  // construye un algoritmo de busqueda bubble sort
}
