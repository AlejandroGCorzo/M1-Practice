class HashTable {
  constructor() {
    this.numBackets = 35;
    this.buckets = [];
  }

  hash(key) {
    // do something...
  }

  set(key, value) {
    // do something...
  }

  get(key) {
    // Este metodo nos devuelve el value dentro de cada objeto de buckets.
  }

  hasKey(key) {
    // Este metodo devuelve true o false si la key indicada se encuentra en nuestra hash table.
  }

  key() {
    // Nos permite obtener todas las key dentro de nuestra hash table
  }

  value() {
    // Nos permite obtener todas los values dentro de nuestra hash table
  }
}
